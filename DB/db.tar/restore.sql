--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.3
-- Dumped by pg_dump version 13.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE msp_vacunacion;
--
-- Name: msp_vacunacion; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE msp_vacunacion WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Spanish_Ecuador.1252';


ALTER DATABASE msp_vacunacion OWNER TO postgres;

\connect msp_vacunacion

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: security; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA security;


ALTER SCHEMA security OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: vc_lote; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vc_lote (
    lo_id integer NOT NULL,
    lo_cantidad bigint NOT NULL,
    lo_estado character varying(2) NOT NULL,
    lo_fecha_expiracion timestamp without time zone NOT NULL,
    lo_fecha_fabricacion timestamp without time zone NOT NULL,
    lo_fecha_ingreso_pais timestamp without time zone,
    lo_fecha_modificacion timestamp without time zone,
    lo_fecha_registro timestamp without time zone NOT NULL,
    lo_numero character varying(64) NOT NULL,
    lo_observacion character varying(200),
    tipo_vacuna_id_tv_id integer NOT NULL
);


ALTER TABLE public.vc_lote OWNER TO postgres;

--
-- Name: vc_lote_auditoria; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vc_lote_auditoria (
    la_id integer NOT NULL,
    la_cantidad integer NOT NULL,
    la_estado character varying(2) NOT NULL,
    la_fecha_expiracion timestamp without time zone NOT NULL,
    la_fecha_fabricacion timestamp without time zone NOT NULL,
    la_fecha_ingreso timestamp without time zone,
    la_fecha_modificacion timestamp without time zone,
    la_fecha_registro timestamp without time zone NOT NULL,
    la_numero character varying(64) NOT NULL,
    la_observacion character varying(100),
    la_operacion character varying(2),
    la_terminal character varying(20),
    lote_id_lo_id integer NOT NULL,
    usuario_id_us_id integer NOT NULL
);


ALTER TABLE public.vc_lote_auditoria OWNER TO postgres;

--
-- Name: vc_lote_auditoria_la_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.vc_lote_auditoria_la_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.vc_lote_auditoria_la_id_seq OWNER TO postgres;

--
-- Name: vc_lote_auditoria_la_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.vc_lote_auditoria_la_id_seq OWNED BY public.vc_lote_auditoria.la_id;


--
-- Name: vc_lote_lo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.vc_lote_lo_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.vc_lote_lo_id_seq OWNER TO postgres;

--
-- Name: vc_lote_lo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.vc_lote_lo_id_seq OWNED BY public.vc_lote.lo_id;


--
-- Name: vc_stock_vacuna; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vc_stock_vacuna (
    sv_id integer NOT NULL,
    sv_cantidad_disponible bigint NOT NULL,
    sv_cantidad_total bigint NOT NULL,
    tipo_vacuna_id_tv_id integer NOT NULL
);


ALTER TABLE public.vc_stock_vacuna OWNER TO postgres;

--
-- Name: vc_stock_vacuna_sv_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.vc_stock_vacuna_sv_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.vc_stock_vacuna_sv_id_seq OWNER TO postgres;

--
-- Name: vc_stock_vacuna_sv_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.vc_stock_vacuna_sv_id_seq OWNED BY public.vc_stock_vacuna.sv_id;


--
-- Name: vc_tipo_vacuna; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vc_tipo_vacuna (
    tv_id integer NOT NULL,
    tv_descripcion character varying(100),
    tv_estado character varying(2) NOT NULL,
    tv_fecha_modificacion timestamp without time zone,
    tv_fecha_registro timestamp without time zone NOT NULL,
    tv_laboratorio character varying(64),
    tv_nombre character varying(64) NOT NULL,
    tv_numero_dosis integer NOT NULL,
    tv_observacion character varying(100),
    tv_temperatura_max double precision NOT NULL,
    tv_temperatura_min double precision NOT NULL,
    tv_tiempo_entre_dosis integer NOT NULL
);


ALTER TABLE public.vc_tipo_vacuna OWNER TO postgres;

--
-- Name: vc_tipo_vacuna_tv_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.vc_tipo_vacuna_tv_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.vc_tipo_vacuna_tv_id_seq OWNER TO postgres;

--
-- Name: vc_tipo_vacuna_tv_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.vc_tipo_vacuna_tv_id_seq OWNED BY public.vc_tipo_vacuna.tv_id;


--
-- Name: vc_rol; Type: TABLE; Schema: security; Owner: postgres
--

CREATE TABLE security.vc_rol (
    ro_id integer NOT NULL,
    ro_descripcion character varying(64),
    ro_estado character varying(2) NOT NULL,
    ro_fecha_modificacion timestamp without time zone,
    ro_fecha_registro timestamp without time zone NOT NULL,
    ro_nombre character varying(64) NOT NULL,
    ro_usuario_modificador integer,
    ro_usuario_registrador integer NOT NULL
);


ALTER TABLE security.vc_rol OWNER TO postgres;

--
-- Name: vc_rol_ro_id_seq; Type: SEQUENCE; Schema: security; Owner: postgres
--

CREATE SEQUENCE security.vc_rol_ro_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE security.vc_rol_ro_id_seq OWNER TO postgres;

--
-- Name: vc_rol_ro_id_seq; Type: SEQUENCE OWNED BY; Schema: security; Owner: postgres
--

ALTER SEQUENCE security.vc_rol_ro_id_seq OWNED BY security.vc_rol.ro_id;


--
-- Name: vc_usuario; Type: TABLE; Schema: security; Owner: postgres
--

CREATE TABLE security.vc_usuario (
    us_id integer NOT NULL,
    us_clave character varying(64) NOT NULL,
    us_descripcion character varying(100),
    us_estado character varying(2) NOT NULL,
    us_fecha_modificacion timestamp without time zone,
    us_fecha_registro timestamp without time zone NOT NULL,
    us_nombre character varying(64) NOT NULL,
    us_usuario_modificador integer,
    us_usuario_registrador integer NOT NULL
);


ALTER TABLE security.vc_usuario OWNER TO postgres;

--
-- Name: vc_usuario_rol; Type: TABLE; Schema: security; Owner: postgres
--

CREATE TABLE security.vc_usuario_rol (
    ur_id integer NOT NULL,
    ur_fecha_modificacion timestamp without time zone,
    ur_fecha_registro timestamp without time zone NOT NULL,
    us_usuario_modificador integer,
    us_usuario_registrador integer NOT NULL,
    rol_id_ro_id integer NOT NULL,
    usuario_id_us_id integer NOT NULL
);


ALTER TABLE security.vc_usuario_rol OWNER TO postgres;

--
-- Name: vc_usuario_rol_ur_id_seq; Type: SEQUENCE; Schema: security; Owner: postgres
--

CREATE SEQUENCE security.vc_usuario_rol_ur_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE security.vc_usuario_rol_ur_id_seq OWNER TO postgres;

--
-- Name: vc_usuario_rol_ur_id_seq; Type: SEQUENCE OWNED BY; Schema: security; Owner: postgres
--

ALTER SEQUENCE security.vc_usuario_rol_ur_id_seq OWNED BY security.vc_usuario_rol.ur_id;


--
-- Name: vc_usuario_us_id_seq; Type: SEQUENCE; Schema: security; Owner: postgres
--

CREATE SEQUENCE security.vc_usuario_us_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE security.vc_usuario_us_id_seq OWNER TO postgres;

--
-- Name: vc_usuario_us_id_seq; Type: SEQUENCE OWNED BY; Schema: security; Owner: postgres
--

ALTER SEQUENCE security.vc_usuario_us_id_seq OWNED BY security.vc_usuario.us_id;


--
-- Name: vc_lote lo_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vc_lote ALTER COLUMN lo_id SET DEFAULT nextval('public.vc_lote_lo_id_seq'::regclass);


--
-- Name: vc_lote_auditoria la_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vc_lote_auditoria ALTER COLUMN la_id SET DEFAULT nextval('public.vc_lote_auditoria_la_id_seq'::regclass);


--
-- Name: vc_stock_vacuna sv_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vc_stock_vacuna ALTER COLUMN sv_id SET DEFAULT nextval('public.vc_stock_vacuna_sv_id_seq'::regclass);


--
-- Name: vc_tipo_vacuna tv_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vc_tipo_vacuna ALTER COLUMN tv_id SET DEFAULT nextval('public.vc_tipo_vacuna_tv_id_seq'::regclass);


--
-- Name: vc_rol ro_id; Type: DEFAULT; Schema: security; Owner: postgres
--

ALTER TABLE ONLY security.vc_rol ALTER COLUMN ro_id SET DEFAULT nextval('security.vc_rol_ro_id_seq'::regclass);


--
-- Name: vc_usuario us_id; Type: DEFAULT; Schema: security; Owner: postgres
--

ALTER TABLE ONLY security.vc_usuario ALTER COLUMN us_id SET DEFAULT nextval('security.vc_usuario_us_id_seq'::regclass);


--
-- Name: vc_usuario_rol ur_id; Type: DEFAULT; Schema: security; Owner: postgres
--

ALTER TABLE ONLY security.vc_usuario_rol ALTER COLUMN ur_id SET DEFAULT nextval('security.vc_usuario_rol_ur_id_seq'::regclass);


--
-- Data for Name: vc_lote; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vc_lote (lo_id, lo_cantidad, lo_estado, lo_fecha_expiracion, lo_fecha_fabricacion, lo_fecha_ingreso_pais, lo_fecha_modificacion, lo_fecha_registro, lo_numero, lo_observacion, tipo_vacuna_id_tv_id) FROM stdin;
\.
COPY public.vc_lote (lo_id, lo_cantidad, lo_estado, lo_fecha_expiracion, lo_fecha_fabricacion, lo_fecha_ingreso_pais, lo_fecha_modificacion, lo_fecha_registro, lo_numero, lo_observacion, tipo_vacuna_id_tv_id) FROM '$$PATH$$/3065.dat';

--
-- Data for Name: vc_lote_auditoria; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vc_lote_auditoria (la_id, la_cantidad, la_estado, la_fecha_expiracion, la_fecha_fabricacion, la_fecha_ingreso, la_fecha_modificacion, la_fecha_registro, la_numero, la_observacion, la_operacion, la_terminal, lote_id_lo_id, usuario_id_us_id) FROM stdin;
\.
COPY public.vc_lote_auditoria (la_id, la_cantidad, la_estado, la_fecha_expiracion, la_fecha_fabricacion, la_fecha_ingreso, la_fecha_modificacion, la_fecha_registro, la_numero, la_observacion, la_operacion, la_terminal, lote_id_lo_id, usuario_id_us_id) FROM '$$PATH$$/3055.dat';

--
-- Data for Name: vc_stock_vacuna; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vc_stock_vacuna (sv_id, sv_cantidad_disponible, sv_cantidad_total, tipo_vacuna_id_tv_id) FROM stdin;
\.
COPY public.vc_stock_vacuna (sv_id, sv_cantidad_disponible, sv_cantidad_total, tipo_vacuna_id_tv_id) FROM '$$PATH$$/3067.dat';

--
-- Data for Name: vc_tipo_vacuna; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vc_tipo_vacuna (tv_id, tv_descripcion, tv_estado, tv_fecha_modificacion, tv_fecha_registro, tv_laboratorio, tv_nombre, tv_numero_dosis, tv_observacion, tv_temperatura_max, tv_temperatura_min, tv_tiempo_entre_dosis) FROM stdin;
\.
COPY public.vc_tipo_vacuna (tv_id, tv_descripcion, tv_estado, tv_fecha_modificacion, tv_fecha_registro, tv_laboratorio, tv_nombre, tv_numero_dosis, tv_observacion, tv_temperatura_max, tv_temperatura_min, tv_tiempo_entre_dosis) FROM '$$PATH$$/3057.dat';

--
-- Data for Name: vc_rol; Type: TABLE DATA; Schema: security; Owner: postgres
--

COPY security.vc_rol (ro_id, ro_descripcion, ro_estado, ro_fecha_modificacion, ro_fecha_registro, ro_nombre, ro_usuario_modificador, ro_usuario_registrador) FROM stdin;
\.
COPY security.vc_rol (ro_id, ro_descripcion, ro_estado, ro_fecha_modificacion, ro_fecha_registro, ro_nombre, ro_usuario_modificador, ro_usuario_registrador) FROM '$$PATH$$/3059.dat';

--
-- Data for Name: vc_usuario; Type: TABLE DATA; Schema: security; Owner: postgres
--

COPY security.vc_usuario (us_id, us_clave, us_descripcion, us_estado, us_fecha_modificacion, us_fecha_registro, us_nombre, us_usuario_modificador, us_usuario_registrador) FROM stdin;
\.
COPY security.vc_usuario (us_id, us_clave, us_descripcion, us_estado, us_fecha_modificacion, us_fecha_registro, us_nombre, us_usuario_modificador, us_usuario_registrador) FROM '$$PATH$$/3061.dat';

--
-- Data for Name: vc_usuario_rol; Type: TABLE DATA; Schema: security; Owner: postgres
--

COPY security.vc_usuario_rol (ur_id, ur_fecha_modificacion, ur_fecha_registro, us_usuario_modificador, us_usuario_registrador, rol_id_ro_id, usuario_id_us_id) FROM stdin;
\.
COPY security.vc_usuario_rol (ur_id, ur_fecha_modificacion, ur_fecha_registro, us_usuario_modificador, us_usuario_registrador, rol_id_ro_id, usuario_id_us_id) FROM '$$PATH$$/3063.dat';

--
-- Name: vc_lote_auditoria_la_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.vc_lote_auditoria_la_id_seq', 1, false);


--
-- Name: vc_lote_lo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.vc_lote_lo_id_seq', 3, true);


--
-- Name: vc_stock_vacuna_sv_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.vc_stock_vacuna_sv_id_seq', 1, false);


--
-- Name: vc_tipo_vacuna_tv_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.vc_tipo_vacuna_tv_id_seq', 4, true);


--
-- Name: vc_rol_ro_id_seq; Type: SEQUENCE SET; Schema: security; Owner: postgres
--

SELECT pg_catalog.setval('security.vc_rol_ro_id_seq', 2, true);


--
-- Name: vc_usuario_rol_ur_id_seq; Type: SEQUENCE SET; Schema: security; Owner: postgres
--

SELECT pg_catalog.setval('security.vc_usuario_rol_ur_id_seq', 3, true);


--
-- Name: vc_usuario_us_id_seq; Type: SEQUENCE SET; Schema: security; Owner: postgres
--

SELECT pg_catalog.setval('security.vc_usuario_us_id_seq', 3, true);


--
-- Name: vc_lote uk_4egk40eobqvx4t2jly5yprv7k; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vc_lote
    ADD CONSTRAINT uk_4egk40eobqvx4t2jly5yprv7k UNIQUE (lo_numero);


--
-- Name: vc_lote_auditoria uk_5rpmesbe0obygnflyl4a9ulwb; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vc_lote_auditoria
    ADD CONSTRAINT uk_5rpmesbe0obygnflyl4a9ulwb UNIQUE (la_numero);


--
-- Name: vc_tipo_vacuna uk_yp1uvte1nxos1r1tcixtadmo; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vc_tipo_vacuna
    ADD CONSTRAINT uk_yp1uvte1nxos1r1tcixtadmo UNIQUE (tv_nombre);


--
-- Name: vc_lote_auditoria vc_lote_auditoria_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vc_lote_auditoria
    ADD CONSTRAINT vc_lote_auditoria_pkey PRIMARY KEY (la_id);


--
-- Name: vc_lote vc_lote_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vc_lote
    ADD CONSTRAINT vc_lote_pkey PRIMARY KEY (lo_id);


--
-- Name: vc_stock_vacuna vc_stock_vacuna_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vc_stock_vacuna
    ADD CONSTRAINT vc_stock_vacuna_pkey PRIMARY KEY (sv_id);


--
-- Name: vc_tipo_vacuna vc_tipo_vacuna_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vc_tipo_vacuna
    ADD CONSTRAINT vc_tipo_vacuna_pkey PRIMARY KEY (tv_id);


--
-- Name: vc_usuario uk_jf206x0wxionbbjnxqkywh5b4; Type: CONSTRAINT; Schema: security; Owner: postgres
--

ALTER TABLE ONLY security.vc_usuario
    ADD CONSTRAINT uk_jf206x0wxionbbjnxqkywh5b4 UNIQUE (us_nombre);


--
-- Name: vc_rol uk_tay8ajm3fo7ossmir5jmsu5ky; Type: CONSTRAINT; Schema: security; Owner: postgres
--

ALTER TABLE ONLY security.vc_rol
    ADD CONSTRAINT uk_tay8ajm3fo7ossmir5jmsu5ky UNIQUE (ro_nombre);


--
-- Name: vc_rol vc_rol_pkey; Type: CONSTRAINT; Schema: security; Owner: postgres
--

ALTER TABLE ONLY security.vc_rol
    ADD CONSTRAINT vc_rol_pkey PRIMARY KEY (ro_id);


--
-- Name: vc_usuario vc_usuario_pkey; Type: CONSTRAINT; Schema: security; Owner: postgres
--

ALTER TABLE ONLY security.vc_usuario
    ADD CONSTRAINT vc_usuario_pkey PRIMARY KEY (us_id);


--
-- Name: vc_usuario_rol vc_usuario_rol_pkey; Type: CONSTRAINT; Schema: security; Owner: postgres
--

ALTER TABLE ONLY security.vc_usuario_rol
    ADD CONSTRAINT vc_usuario_rol_pkey PRIMARY KEY (ur_id);


--
-- Name: vc_lote fk66or6odgvep3xnj2uxl44nw4c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vc_lote
    ADD CONSTRAINT fk66or6odgvep3xnj2uxl44nw4c FOREIGN KEY (tipo_vacuna_id_tv_id) REFERENCES public.vc_tipo_vacuna(tv_id);


--
-- Name: vc_lote_auditoria fk7j9bbrd8btwuk57feny7m9ekh; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vc_lote_auditoria
    ADD CONSTRAINT fk7j9bbrd8btwuk57feny7m9ekh FOREIGN KEY (lote_id_lo_id) REFERENCES public.vc_lote(lo_id);


--
-- Name: vc_stock_vacuna fkbf4bdx2oghvi8thmi7hyd31ba; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vc_stock_vacuna
    ADD CONSTRAINT fkbf4bdx2oghvi8thmi7hyd31ba FOREIGN KEY (tipo_vacuna_id_tv_id) REFERENCES public.vc_tipo_vacuna(tv_id);


--
-- Name: vc_lote_auditoria fkrg9na8oti5c74b9xdfyhiigpy; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vc_lote_auditoria
    ADD CONSTRAINT fkrg9na8oti5c74b9xdfyhiigpy FOREIGN KEY (usuario_id_us_id) REFERENCES security.vc_usuario(us_id);


--
-- Name: vc_usuario_rol fkiii663a5e1pmqqj5ru545tioa; Type: FK CONSTRAINT; Schema: security; Owner: postgres
--

ALTER TABLE ONLY security.vc_usuario_rol
    ADD CONSTRAINT fkiii663a5e1pmqqj5ru545tioa FOREIGN KEY (usuario_id_us_id) REFERENCES security.vc_usuario(us_id);


--
-- Name: vc_usuario_rol fkiuclsrss964u38jfwg7venl3l; Type: FK CONSTRAINT; Schema: security; Owner: postgres
--

ALTER TABLE ONLY security.vc_usuario_rol
    ADD CONSTRAINT fkiuclsrss964u38jfwg7venl3l FOREIGN KEY (rol_id_ro_id) REFERENCES security.vc_rol(ro_id);


--
-- PostgreSQL database dump complete
--

